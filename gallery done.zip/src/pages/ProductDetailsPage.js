import React, { Component } from 'react';
import './ProductDetailsPageStyle.css';
import Slider from '../components/Slider.js'



class ProductDetailsPage extends Component {
  constructor(props) {
    super(props);
    this.state = {
        id:"",
        product:[],
    };
  }

  componentDidMount() {
    const {currentProductId} = this.props;

    if(currentProductId){
    fetch('http://shehab-gamal334.serv00.net:38837/graphql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: `{getProductById(id:"${currentProductId}"){ id name  description brand amount currency_symbol}}`,
      }),
    })
      .then((res) => res.json())
      .then((data) =>
        this.setState({
          product: data.data.getProductById
        })
      )
      .catch((error) => {
        console.error('Error fetching categories:', error);
      });
  }
  }
  removeHTMLTags(htmlString) {
    
    const parser = new DOMParser();
    
    const doc = parser.parseFromString(htmlString, 'text/html');
    
    const textContent = doc.body.textContent || "";
    
    return textContent.trim();
}

  render() {
    
    return (
     <div className='holder'>
     <Slider id={this.state.product.id}/>
     <div className='product-properities'>
        <div className='name'>
          {this.state.product.name}
        </div>
        <div className='size'>
          <div className='size-tag'>SIZE:</div>
            <div className='choices'> 
              <div className='size-choice'>XS</div>
              <div className='size-choice'>S</div>
              <div className='size-choice'>M</div>
              <div className='size-choice'>L</div>
          </div>
        </div> 
        <div className='colors'>
          <div className='color-tag'>COLOR:</div>
            <div className='choices'> 
              <div className='option A'></div>
              <div className='option B'></div>
              <div className='option C'></div>
          </div>
        </div>
        <div className='price'>
          <div className='price-tag'>PRICE:</div>
          <div className='price-amount'>{this.state.product.currency_symbol}{this.state.product.amount}</div>
        </div>
        <button className='add-to-cart'>
        Add to cart
        </button>
        <div className='description'>
          {this.removeHTMLTags(this.state.product.description)}
        </div>
     </div>
     </div>)
 }}

export default ProductDetailsPage;
